default_app_config = 'demo.periods.apps.PeriodsConfig'
