from django.apps import AppConfig


class MaterialConfig(AppConfig):
    name = 'material'

